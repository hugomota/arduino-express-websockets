module.exports = require('./assignInAll');
