var convert = require('./convert'),
    func = convert('rearg', require('../rearg'));

func.placeholder = require('./placeholder');
module.exports = func;
